// let currentTransport;

// async function connect() 
// {
//     const url = "https://localhost:4433";
//     try {
//         var transport = new WebTransport(url);
//         addToEventLog('Initiating WebTransport connection...');
//         await transport.ready.then(() => {
//             addToEventLog('WebTransport connection established.');
//         }).catch(e => {
//             addToEventLog('Connection failed: ' + e, 'error');
//         });
//         currentTransport = transport;

//         const canvas = document.createElement('canvas');
//         const ctx = canvas.getContext('2d');
//         if (!ctx) {
//             addToEventLog('Failed to get 2D context for canvas.', 'error');
//             return;
//         }
//         canvas.width = 640;
//         canvas.height = 480;
//         canvas.style.border = '1px solid black';
//         canvas.style.display = 'block';
//         document.body.appendChild(canvas);

//         const reader = transport.incomingUnidirectionalStreams.getReader();
//         const processStreams = async () => {
//             while (true) {
//                 const { value: stream, done } = await reader.read();
//                 if (done) {
//                     addToEventLog('Stream reader closed.', 'info');
//                     break;
//                 }
//                 await readVideoStream(stream, ctx);
//             }
//         };
//         processStreams();
//     } catch (e) {
//         addToEventLog('Connection failed: ' + e, 'error');
//     }
// }

// async function readVideoStream(stream, ctx) {
//     try {
//         const reader = stream.getReader();
//         let frameCount = 0;
//         let buffer = new Uint8Array();  

//         const processFrame = (data) => {
//             const blob = new Blob([data], { type: 'image/jpeg' });
//             const url = URL.createObjectURL(blob);
//             const img = new Image();
//             img.onload = () => {
//                 ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
//                 ctx.drawImage(img, 0, 0, ctx.canvas.width, ctx.canvas.height);
//                 frameCount++;
//                 URL.revokeObjectURL(url);
//             };
//             img.onerror = (e) => {
//                 addToEventLog(`Image load error: Failed to load frame (size: ${data.byteLength} bytes)`, 'error');
//             };
//             img.src = url;
//         };

//         while (true) {
//             const { value, done } = await reader.read();
//             if (done) {
//                 addToEventLog('Stream closed.', 'info');
//                 break;
//             }
//             if (value) {
//                 const newBuffer = new Uint8Array(buffer.length + value.length);
//                 newBuffer.set(buffer);
//                 newBuffer.set(value, buffer.length);
//                 buffer = newBuffer;

//                 let startIdx = -1;
//                 let endIdx = -1;
//                 for (let i = 0; i < buffer.length - 1; i++) {
//                     if (buffer[i] === 0xFF && buffer[i + 1] === 0xD8) {
//                         startIdx = i;
//                     }
//                     if (buffer[i] === 0xFF && buffer[i + 1] === 0xD9) {
//                         endIdx = i + 1;
//                     }
//                     if (startIdx !== -1 && endIdx !== -1 && startIdx < endIdx) {
//                         const frameData = buffer.slice(startIdx, endIdx + 1);
//                         processFrame(frameData);
//                         buffer = buffer.slice(endIdx + 1);  
//                         startIdx = -1;
//                         endIdx = -1;
//                     }
//                 }
//             }
//         }
//     } catch (e) {
//         addToEventLog('Error in readVideoStream: ' + e, 'error');
//     }
// }

// function addToEventLog(text, severity = 'info') {
//     let log = document.getElementById('event-log');
//     let entry = document.createElement('li');
//     entry.innerText = text;
//     entry.className = 'log-' + severity;
//     log.appendChild(entry);
//     entry.scrollIntoView();
// }

// window.onload = connect;

let currentTransport;

//  serves as entry point for establishing a WebTransport connection to the server 
async function connect() 
{
    const url = "https://localhost:4433";
    try {
        var transport = new WebTransport(url);
        addToEventLog('Initiating WebTransport connection...');
        await transport.ready.then(() => {
            addToEventLog('WebTransport connection established.');
        }).catch(e => {
            addToEventLog('Connection failed: ' + e, 'error');
        });
        currentTransport = transport;

        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) {
            addToEventLog('Failed to get 2D context for canvas.', 'error');
            return;
        }
        canvas.width = 640;
        canvas.height = 480;
        canvas.style.border = '1px solid black';
        canvas.style.display = 'block';
        document.body.appendChild(canvas);

        const reader = transport.incomingUnidirectionalStreams.getReader();
        const processStreams = async () => {
            while (true) {
                const { value: stream, done } = await reader.read();
                if (done) {
                    addToEventLog('Stream reader closed.', 'info');
                    break;
                }
                await readVideoStream(stream, ctx);
            }
        };
        processStreams();
    } catch (e) {
        addToEventLog('Connection failed: ' + e, 'error');
    }
}

// readVideoStream processes WebTransport stream and puts video frames on canvas in browser.
async function readVideoStream(stream, ctx) {
    try {
        const reader = stream.getReader();
        let frameCount = 0;
        let buffer = new Uint8Array();  

        const processFrame = (data) => {
            const blob = new Blob([data], { type: 'image/jpeg' });
            const url = URL.createObjectURL(blob);
            const img = new Image();
            img.onload = () => {
                ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
                ctx.drawImage(img, 0, 0, ctx.canvas.width, ctx.canvas.height);
                frameCount++;
                URL.revokeObjectURL(url);
            };
            img.onerror = (e) => {
                addToEventLog(`Image load error: Failed to load frame (size: ${data.byteLength} bytes)`, 'error');
            };
            img.src = url;
        };

        while (true) {
            const { value, done } = await reader.read();
            if (done) {
                addToEventLog('Stream closed.', 'info');
                break;
            }
            if (value) {
                const newBuffer = new Uint8Array(buffer.length + value.length);
                newBuffer.set(buffer);
                newBuffer.set(value, buffer.length);
                buffer = newBuffer;

                let startIdx = -1;
                let endIdx = -1;
                for (let i = 0; i < buffer.length - 1; i++) {
                    if (buffer[i] === 0xFF && buffer[i + 1] === 0xD8) {
                        startIdx = i;
                    }
                    if (buffer[i] === 0xFF && buffer[i + 1] === 0xD9) {
                        endIdx = i + 1;
                    }
                    if (startIdx !== -1 && endIdx !== -1 && startIdx < endIdx) {
                        const frameData = buffer.slice(startIdx, endIdx + 1);
                        processFrame(frameData);
                        buffer = buffer.slice(endIdx + 1);  
                        startIdx = -1;
                        endIdx = -1;
                    }
                }
            }
        }
    } catch (e) {
        addToEventLog('Error in readVideoStream: ' + e, 'error');
    }
}

// addToEventLog documents all messages to browswer -- used for all logging (very helpful don't delete) 
function addToEventLog(text, severity = 'info') {
    let log = document.getElementById('event-log');
    let entry = document.createElement('li');
    entry.innerText = text;
    entry.className = 'log-' + severity;
    log.appendChild(entry);
    entry.scrollIntoView();
}

window.onload = connect;