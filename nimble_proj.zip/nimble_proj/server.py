# # !/usr/bin/env python3
# import argparse
# import asyncio
# import logging
# from typing import Optional
# import threading
# import time
# import cv2
# import numpy as np
# from aioquic.asyncio import QuicConnectionProtocol, serve
# from aioquic.h3.connection import H3_ALPN, H3Connection
# from aioquic.h3.events import H3Event, HeadersReceived, WebTransportStreamDataReceived
# from aioquic.quic.configuration import QuicConfiguration
# from aioquic.quic.events import ProtocolNegotiated, StreamReset, QuicEvent

# BIND_ADDRESS = 'localhost'
# BIND_PORT = 4433
# FRAME_RATE = 100  # Frames per second

# logger = logging.getLogger(__name__)

# class VideoGenerator:
#     def __init__(self, queue, loop):
#         self.queue = queue
#         self.loop = loop  # asyncio event loop from the main thread
#         self.width, self.height = 640, 480
#         self.ball_radius = 20
#         self.ball_x, self.ball_y = self.width // 2, self.height // 2
#         self.dx, self.dy = 5, 5

#     def generate_frames(self):
#         last_time = time.time()
#         while True:
#             frame = np.zeros((self.height, self.width, 3), dtype=np.uint8)
#             self.ball_x += self.dx
#             self.ball_y += self.dy
            
#             # Bounce logic
#             if self.ball_x - self.ball_radius < 0 or self.ball_x + self.ball_radius > self.width:
#                 self.dx = -self.dx
#             if self.ball_y - self.ball_radius < 0 or self.ball_y + self.ball_radius > self.height:
#                 self.dy = -self.dy
                
#             cv2.circle(frame, (int(self.ball_x), int(self.ball_y)), self.ball_radius, (0, 255, 0), -1)
#             ret, buffer = cv2.imencode('.jpg', frame)
#             frame_data = buffer.tobytes()
#             asyncio.run_coroutine_threadsafe(self.queue.put(frame_data), self.loop)
            
#             # Precise timing to maintain frame rate
#             current_time = time.time()
#             sleep_time = max(0, (1 / FRAME_RATE) - (current_time - last_time))
#             time.sleep(sleep_time)
#             last_time = current_time

# class WebTransportProtocol(QuicConnectionProtocol):
#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         self._http: Optional[H3Connection] = None
#         self._video_queue = asyncio.Queue()
#         self._loop = asyncio.get_running_loop()
#         self._video_thread = threading.Thread(target=self._start_video_generator, daemon=True)
#         self._video_thread.start()
#         self._stream_id = None

#     def _start_video_generator(self):
#         generator = VideoGenerator(self._video_queue, self._loop)
#         generator.generate_frames()

#     def quic_event_received(self, event: QuicEvent) -> None:
#         if isinstance(event, ProtocolNegotiated):
#             self._http = H3Connection(self._quic, enable_webtransport=True)
#             asyncio.create_task(self._send_video_frames())
#         elif isinstance(event, StreamReset):
#             if self._stream_id == event.stream_id:
#                 self._stream_id = None

#         if self._http is not None:
#             for h3_event in self._http.handle_event(event):
#                 self._h3_event_received(h3_event)

#     async def _send_video_frames(self):
#         while True:
#             frame = await self._video_queue.get()
#             if self._stream_id is not None:
#                 self._http._quic.send_stream_data(self._stream_id, frame, end_stream=False)
#             else:
#                 print("No active stream ID, dropping frame")
#             await asyncio.sleep(1 / FRAME_RATE) 

#     def _h3_event_received(self, event: H3Event) -> None:
#         if isinstance(event, HeadersReceived):
#             headers = {header: value for header, value in event.headers}
#             if headers.get(b":method") == b"CONNECT" and headers.get(b":protocol") == b"webtransport":
#                 self._stream_id = self._http.create_webtransport_stream(event.stream_id, is_unidirectional=True)
#                 self._send_response(event.stream_id, 200)
#             else:
#                 self._send_response(event.stream_id, 400, end_stream=True)

#     def _send_response(self, stream_id: int, status_code: int, end_stream=False) -> None:
#         headers = [(b":status", str(status_code).encode())]
#         if status_code == 200:
#             headers.append((b"sec-webtransport-http3-draft", b"draft02"))
#         self._http.send_headers(stream_id=stream_id, headers=headers, end_stream=end_stream)

# if __name__ == '__main__':
#     parser = argparse.ArgumentParser()
#     parser.add_argument('certificate')
#     parser.add_argument('key')
#     args = parser.parse_args()

#     configuration = QuicConfiguration(
#         alpn_protocols=H3_ALPN,
#         is_client=False,
#         max_datagram_frame_size=65536,
#     )
#     configuration.load_cert_chain(args.certificate, args.key)

#     async def main():
#         server = await serve(
#             BIND_ADDRESS,
#             BIND_PORT,
#             configuration=configuration,
#             create_protocol=WebTransportProtocol,
#         )
#         print(f"Listening on https://{BIND_ADDRESS}:{BIND_PORT}")
#         await asyncio.Future()

#     try:
#         asyncio.run(main())
#     except KeyboardInterrupt:
#         pass

import argparse
import asyncio
import logging
from typing import Optional
import threading
import time
import cv2
import numpy as np
from aioquic.asyncio import QuicConnectionProtocol, serve
from aioquic.h3.connection import H3_ALPN, H3Connection
from aioquic.h3.events import H3Event, HeadersReceived, WebTransportStreamDataReceived
from aioquic.quic.configuration import QuicConfiguration
from aioquic.quic.events import ProtocolNegotiated, StreamReset, QuicEvent

BIND_ADDRESS = 'localhost'
BIND_PORT = 4433
FRAME_RATE = 100


# VideoGenerator is responsible for generating video frames featuring a bouncing green ball 
class VideoGenerator:
    # initializes the frame queue, event loop, canvas dimensions, ball properties (radius, position, and velocity) 
    def __init__(self, queue, loop):
        self.queue = queue
        self.loop = loop
        self.width, self.height = 640, 480
        self.ball_radius = 20
        self.ball_x, self.ball_y = self.width // 2, self.height // 2
        self.dx, self.dy = 5, 5

    # generate_frames runs an infinite loop to produce frames, updates ball's position 
    def generate_frames(self):
        last_time = time.time()
        while True:
            frame = np.zeros((self.height, self.width, 3), dtype=np.uint8)
            self.ball_x += self.dx
            self.ball_y += self.dy
            
            if self.ball_x - self.ball_radius < 0 or self.ball_x + self.ball_radius > self.width:
                self.dx = -self.dx
            if self.ball_y - self.ball_radius < 0 or self.ball_y + self.ball_radius > self.height:
                self.dy = -self.dy
                
            cv2.circle(frame, (int(self.ball_x), int(self.ball_y)), self.ball_radius, (0, 255, 0), -1)
            ret, buffer = cv2.imencode('.jpg', frame)
            frame_data = buffer.tobytes()
            asyncio.run_coroutine_threadsafe(self.queue.put(frame_data), self.loop)
            
            current_time = time.time()
            sleep_time = max(0, (1 / FRAME_RATE) - (current_time - last_time))
            time.sleep(sleep_time)
            last_time = current_time

# WebTransportProtocol manages the server-side WebTransport connection, facilitating the transmission of video frames to clients over QUIC. 
class WebTransportProtocol(QuicConnectionProtocol):
    # init  sets up the HTTP/3 connection object, queue for video frames, and starts a thread to generate frames via _start_video_generator. 
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._http: Optional[H3Connection] = None
        self._video_queue = asyncio.Queue()
        self._loop = asyncio.get_running_loop()
        self._video_thread = threading.Thread(target=self._start_video_generator, daemon=True)
        self._video_thread.start()
        self._stream_id = None

    def _start_video_generator(self):
        generator = VideoGenerator(self._video_queue, self._loop)
        generator.generate_frames()

    # processes QUIC events and initializes the HTTP/3 connection, also handles stream resets. 
    def quic_event_received(self, event: QuicEvent) -> None:
        if isinstance(event, ProtocolNegotiated):
            self._http = H3Connection(self._quic, enable_webtransport=True)
            asyncio.create_task(self._send_video_frames())
        elif isinstance(event, StreamReset):
            if self._stream_id == event.stream_id:
                self._stream_id = None

        if self._http is not None:
            for h3_event in self._http.handle_event(event):
                self._h3_event_received(h3_event)

    # continuously retrieves frames from queue and sends them over the stream, keeps sending at 100 FPS
    async def _send_video_frames(self):
        while True:
            frame = await self._video_queue.get()
            if self._stream_id is not None:
                self._http._quic.send_stream_data(self._stream_id, frame, end_stream=False)
            else:
                print("No active stream ID, dropping frame")
            await asyncio.sleep(1 / FRAME_RATE)

    # method processes HTTP/3 events, creating a unidirectional stream upon client connection
    def _h3_event_received(self, event: H3Event) -> None:
        if isinstance(event, HeadersReceived):
            headers = {header: value for header, value in event.headers}
            if headers.get(b":method") == b"CONNECT" and headers.get(b":protocol") == b"webtransport":
                self._stream_id = self._http.create_webtransport_stream(event.stream_id, is_unidirectional=True)
                self._send_response(event.stream_id, 200)
            else:
                self._send_response(event.stream_id, 400, end_stream=True)

    # constructs appropriate HTTP headers for responses
    def _send_response(self, stream_id: int, status_code: int, end_stream=False) -> None:
        headers = [(b":status", str(status_code).encode())]
        if status_code == 200:
            headers.append((b"sec-webtransport-http3-draft", b"draft02"))
        self._http.send_headers(stream_id=stream_id, headers=headers, end_stream=end_stream)

# parses command-line arguments for the SSL certificate and key files and sets up configuration of QUIC server
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('certificate')
    parser.add_argument('key')
    args = parser.parse_args()

    configuration = QuicConfiguration(
        alpn_protocols=H3_ALPN,
        is_client=False,
        max_datagram_frame_size=65536,
    )
    configuration.load_cert_chain(args.certificate, args.key)

    # keeps server continously running
    async def main():
        server = await serve(
            BIND_ADDRESS,
            BIND_PORT,
            configuration=configuration,
            create_protocol=WebTransportProtocol,
        )
        print(f"Listening on https://{BIND_ADDRESS}:{BIND_PORT}")
        await asyncio.Future()

    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass